<?php
echo json_encode([
    "id" => "https://lti-tool.elephango.com/platform/gs/groups",
    "groups" => [
        [
            "id" => "4b8ae5e8-4de4-438f-92d3-6b856195293b",
            "name" => "Team A",
            "set_id" => "10174933-066a-43b0-8eea-2a14e13ad2e7",
            "tag" => "team",
        ],
        [
            "id" => "b2edddff-6dcc-4372-9f2c-410f954ba48f",
            "name" => "Team B",
            "set_id" => "10174933-066a-43b0-8eea-2a14e13ad2e7",
            "tag" => "team",
        ],
    ]

]);
?>
<?php
echo json_encode([
    "id" => "https://lti-tool.elephango.com/platform/gs/sets",
    "sets" => [
        [
            "id" => "10174933-066a-43b0-8eea-2a14e13ad2e7",
            "name" => "Teams",
        ]
    ]

]);
?>